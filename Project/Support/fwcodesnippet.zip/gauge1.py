import pygame, sys, random
from pygame.locals import *

pygame.init()


# set up the window
DISPLAYSURF = pygame.display.set_mode((1200, 500), 0, 32)
pygame.display.set_caption('GUAGE')

WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
BLUE = (0, 0, 128)
BGCOLOR = (72, 79, 66)
STRING = 'Speed'
variable = 10

gaugeImg = pygame.image.load('pic.png')
needleImg = pygame.image.load('needle.png')

fontObj = pygame.font.Font('VolvoSansProHybrid-Light.ttf', 32)

textSurfaceObj = fontObj.render(STRING, False, (255, 0, 0), WHITE)
textRectObj = textSurfaceObj.get_rect()
textRectObj.center = (900, 150)

number = 0 #random.randrange(5, 15)
numberDisplay = fontObj.render(str(number), 1, WHITE)

diceRoll = random.randrange(0, 5)
diceDisplay = fontObj.render(str(diceRoll), 1, WHITE)
#DISPLAYSURF.blit(diceDisplay, (900, 300))

#keys=pygame.key.get_pressed()

while True: # the main game loop
    DISPLAYSURF.fill(BGCOLOR)

    DISPLAYSURF.blit(gaugeImg, (10, 10))
    DISPLAYSURF.blit(needleImg, (90, 90))
    DISPLAYSURF.blit(textSurfaceObj, textRectObj)
    
    pygame.transform.rotate((needleImg).convert(), 180)

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                number -= 1
                #DISPLAYSURF.blit(numberDisplay, (900, 400))
                print ('left')
            if event.key == pygame.K_RIGHT:
                number += 1
                #DISPLAYSURF.blit(numberDisplay, (900, 400))
                print ('right')
        
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                pygame.transform.rotate((needleImg).convert(), 180)

    numberDisplay = fontObj.render(str(number), 1, WHITE)
    DISPLAYSURF.blit(numberDisplay, (900, 250))
    DISPLAYSURF.blit(needleImg, (90, 180))
    pygame.display.update()
